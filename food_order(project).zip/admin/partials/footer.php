 <!-- footer section starts -->
 <div class="footer">
        <div class="wrapper">
            <p class="text-center">2022 All rights reserved,Food House Developed by -<a href="#">
                    Sahana.s.n</a></p>
        </div>
    </div>
    <!-- footer section ends -->
</body>

</html>